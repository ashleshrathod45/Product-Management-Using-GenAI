// package com.productmanagement.controller;

// import com.productmanagement.model.User;
// import com.productmanagement.repository.UserRepository;
// import com.productmanagement.security.JwtUtil;
// import org.springframework.security.access.prepost.PreAuthorize;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.web.bind.annotation.*;

// @RestController
// @RequestMapping("/api/auth")
// public class AuthController {
//     private final UserRepository userRepository;
//     private final PasswordEncoder passwordEncoder;
//     private final JwtUtil jwtUtil;

//     public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
//         this.userRepository = userRepository;
//         this.passwordEncoder = passwordEncoder;
//         this.jwtUtil = jwtUtil;
//     }

//     @PostMapping("/register")
//     // @PreAuthorize("hasAuthority('ADMIN')")
//     public String register(@RequestBody User user) {
//         user.setPassword(passwordEncoder.encode(user.getPassword()));
//         userRepository.save(user);
//         return "User registered";
//     }

//     @PostMapping("/login")
//     public String login(@RequestBody User user) {
//         User dbUser = userRepository.findByUsername(user.getUsername());
//         if (dbUser != null && passwordEncoder.matches(user.getPassword(), dbUser.getPassword())) {
//             return jwtUtil.generateToken(dbUser.getUsername(), dbUser.getRole());
//         }
//         return "Invalid credentials";
//     }

//     @GetMapping("/me")
//     @PreAuthorize("isAuthenticated()")
//     public User getCurrentUser(@RequestHeader("Authorization") String token) {
//         String username = jwtUtil.extractUsername(token.replace("Bearer ", ""));
//         return userRepository.findByUsername(username);
//     }
// }


package com.productmanagement.controller;

import com.productmanagement.model.User;
import com.productmanagement.repository.UserRepository;
import com.productmanagement.security.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        if (userRepository.findByUsername(user.getUsername()) != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already exists");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        User dbUser = userRepository.findByUsername(user.getUsername());

        if (dbUser == null || !passwordEncoder.matches(user.getPassword(), dbUser.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }

        String token = jwtUtil.generateToken(dbUser.getUsername(), dbUser.getRole());

        Map<String, String> response = new HashMap<>();
        response.put("token", token);
        return ResponseEntity.ok(response);
    }
}
